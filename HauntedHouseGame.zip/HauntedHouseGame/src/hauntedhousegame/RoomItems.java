/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hauntedhousegame;

import javax.swing.JOptionPane;
import javax.swing.ImageIcon;

/**
 *
 * @author dailenperez
 */

public class RoomItems {

    // initializes an array to store the possible room items per room
    private String[] roomItems;
    // This deadly variable will be set to true if the item explored is deadly so that i can adjust my end game message in the player class accrodingly 
    private boolean deadly = false;
    // These two variables will store the outcome of exploring an object and a picture of all the items in the room depending on the current room they're in
    private ImageIcon itemOutcomeImage;
    private ImageIcon roomItemsImage;

  
    
    
    //This method matches the current room to the items that can be explored in that room, and image that has them
    public void availableRoomItems(int currentRoom) {
        if (currentRoom == 1) {
            roomItems = new String[]{
                "Next", "Chest"
            };
            roomItemsImage = new ImageIcon("livingRoom.png");

        } else if (currentRoom == 2) {
            roomItems = new String[]{
                "Next", "Mirror", "Shower"
            };
            roomItemsImage = new ImageIcon("bathroom1.png");

        } else if (currentRoom == 3) {
            roomItems = new String[]{
                "Next", "Candelabra"
            };
            roomItemsImage = new ImageIcon("diningRoom.png");

        } else if (currentRoom == 4) {
            roomItems = new String[]{
                "Next", "Refrigerator", "Cabinet"
            };
            roomItemsImage = new ImageIcon("kitchen.png");

        } else if (currentRoom == 5) {
            roomItems = new String[]{
                "Next", "Dusty Recipe Box", "Broom"
            };
            roomItemsImage = new ImageIcon("pantry.png");

        } else if (currentRoom == 6) {
            roomItems = new String[]{
                "Next", "Rocking Chair", "Window"
            };
            roomItemsImage = new ImageIcon("bedroom1.png");

        } else if (currentRoom == 7) {
            roomItems = new String[]{
                "Next", "Mirror", "Shower"
            };
            roomItemsImage = new ImageIcon("bathroom2.png");

        } else if (currentRoom == 8) {

            roomItems = new String[]{
                "Next", "Doll House", "Dresser"
            };
            roomItemsImage = new ImageIcon("bedroom2.png");

        } else if (currentRoom == 9) {

            roomItems = new String[]{
                "Next", "Jewelry Box"
            };
            roomItemsImage = new ImageIcon("masterBedroom.png");
        } else if (currentRoom == 10) {

            roomItems = new String[]{
                "Next", "Intricate Oil Lamp", "Shower"
            };
            roomItemsImage = new ImageIcon("masterBathroom.png");
        } else {
            roomItems = new String[]{
                "None"
            };

        }

    }

    //This method matches the room item selected to the text and image outcome of exploring that item.
    public String itemOutcome(String item, int currentRoomNumber) {
        String outcome = "";
        if (item.equals("Chest")) {

            outcome = "A ghost has escaped and scared you to death !";

            itemOutcomeImage = new ImageIcon("livingRoomScare.png");
            deadly = true;

        } else if (item.equals("Candelabra")) {

            outcome = "The candelabras are lighting up! I see death's shadow...";

            itemOutcomeImage = new ImageIcon("diningRoomScare.png");
            deadly = true;
        } else if (item.equals("Refrigerator")) {

            outcome = "Yummm there is soul food in here!";
            itemOutcomeImage = new ImageIcon("kitchenScare.png");

        } else if (item.equals("Cabinet")) {

            outcome = "Dishes and glasses are flying at me ! I am moving towards the light...";

            itemOutcomeImage = new ImageIcon("kitchenScare2.png");
            deadly = true;
        } else if (item.equals("Dusty Recipe Box")) {

            outcome = "Ooh ! A recipe for devil's food cake.";
            itemOutcomeImage = new ImageIcon("pantry.png");

        } else if (item.equals("Broom")) {

            outcome = "The broom has flown up into the air!";
            itemOutcomeImage = new ImageIcon("pantryScare.png");

        } else if (item.equals("Mirror") && currentRoomNumber == 2) {

            outcome = "Aaaaah! A bloody face is looking back at me!";
            itemOutcomeImage = new ImageIcon("bathroom1Scare.png");

        } else if (item.equals("Mirror") && currentRoomNumber == 7) {

            outcome = "Aaaaah! A bloody face is looking back at me!";
            itemOutcomeImage = new ImageIcon("bathroom2Scare.png");

        } else if (item.equals("Rocking Chair")) {

            outcome = "The chair is rocking by itself...";
            itemOutcomeImage = new ImageIcon("bedroom1Scare2.png");
        } else if (item.equals("Window")) {

            outcome = "There is a child otuside on the swing. Wait nevermind , he's dissapeared!";
            itemOutcomeImage = new ImageIcon("bedroom1Scare.png");
        } else if (item.equals("Doll House")) {

            outcome = "The dolls have started to dance on their own!";
            itemOutcomeImage = new ImageIcon("bedroom2Scare.png");
        } else if (item.equals("Dresser")) {

            outcome = "When I opened the dresser there was a ghost.I have felt it go through my body as it escaped.";
            itemOutcomeImage = new ImageIcon("bedroom2Scare2.png");
            deadly = true;
        } else if (item.equalsIgnoreCase("Jewelry Box")) {

            outcome = "Is this the cursed Hope Diamond?! I feel my impending doom.";
            itemOutcomeImage = new ImageIcon("masterBedroomScare.png");
            deadly = true;
        } else if (item.equals("Intricate Oil Lamp")) {

            outcome = "I have rubbed this lamp and alas now a genie has agreed to grant me three wishes!";
            itemOutcomeImage = new ImageIcon("masterBathroomScare2.png");

        } else if (item.equals("Shower") && currentRoomNumber == 2) {
            outcome = "I can barely see the room has steamed up.Aaahhh there are fingers touching the back of my neck!";
            itemOutcomeImage = new ImageIcon("bathroom1Scare2.png");
            deadly = true;

        } else if (item.equals("Shower") && currentRoomNumber == 7) {

            outcome = "I can barely see the room has steamed up.Aaahhh there are fingers touching the back of my neck!";
            itemOutcomeImage = new ImageIcon("bathroom2Scare2.png");
            deadly = true;

        } 
        else if (item.equals("Shower") && currentRoomNumber == 10) {

            outcome = "Curious , there was singing in the shower but no one was there.";
            itemOutcomeImage = new ImageIcon("masterBathroom.png");

        } else {
            outcome = "Next";
        }

        return outcome;
    }
        // Getters necessary
    public String[] geRoomItemsArray() {
        return roomItems;
    }
    public boolean getIsDeadly() {
        return deadly;
    }

    public ImageIcon getItemOutcomeImage() {
        return itemOutcomeImage;
    }

    public ImageIcon getRoomItemsImage() {
        return roomItemsImage;
    }
}
