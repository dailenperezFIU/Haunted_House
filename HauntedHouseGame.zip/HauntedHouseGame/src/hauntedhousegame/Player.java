/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hauntedhousegame;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.*;


/**
 *
 * @author dailenperez
 */
public class Player {

// Iniitalizing a HauntedHouse and roomItems object to be able to use variables and methods from both classes
    private String backpack = "The item in my backpack was: ";
    private boolean gameOver = false;
    private HauntedHouse house = new HauntedHouse();
    private RoomItems roomItems2 = new RoomItems();
// Initializing variables to hold the current room number and current picture I need to display to the player.    
    private int currentRoomNumber = 0;
    private ImageIcon updatedRoomMap;

    // This method asks the player where they want to go and moves them there if the move is possible. The player is only given the possible choices in the drop down so that assures that their input is valid.
    public void MovePlayer() {

        // Calling possible moves to the first current room number which is always zero(the front door.)
        house.possibleMoves(currentRoomNumber);

        // an image of the current room is returned by this  method and i'm saving it into updatedRoomMap variable.
        updatedRoomMap = house.currentRoom(currentRoomNumber);

        String input = (String) (JOptionPane.showInputDialog(null, "Choose the number of the room you'd like to explore",
                "Haunted House Blueprint", JOptionPane.QUESTION_MESSAGE, updatedRoomMap, house.getPossibleRoomsArray(), (house.getPossibleRoomsArray()[0])));

        currentRoomNumber = Integer.parseInt(input);

        // update room map again after they've picked a new room 
        updatedRoomMap = house.currentRoom(currentRoomNumber);

    }

    public void exploreRoomItems() {

        // Calling method that creates a room Item array depending on the current room
        roomItems2.availableRoomItems(currentRoomNumber);
        int x = 1;
        String answer;
        // local array I'm using to easily use the possible room items array I made in other class.
        Object[] itemOptions = roomItems2.geRoomItemsArray();

        // If an invalid room number is entered by chance then this if will exit this method so the user can pick the room again.
        if (itemOptions[0].equals("None")) {
            return;
        }

        // The below J Option pane returns the index number of the item the person chose from the roomItems array
        x = JOptionPane.showOptionDialog(null, "This room has some interesting items.\nClick their button to check them out and place them in your backpack.\nClick Next to move on. ", "Explore Items",
                JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, roomItems2.getRoomItemsImage(), itemOptions, itemOptions[0]);

        // To easily pass it to my item Outcome method I take whatever actual word was in that index
        answer = (String) itemOptions[x];
        // If the person chose the index that has next then i exit this method so the person can go back to choosing what room to go to.
        if (roomItems2.itemOutcome(answer, currentRoomNumber).equals("Next")) {
            return;
        }
        // If their answer isn't next then i Add the item they chose to the bakcpack string.          
        backpack += answer + " ";

        JOptionPane.showMessageDialog(null, roomItems2.itemOutcome(answer, currentRoomNumber), "", JOptionPane.PLAIN_MESSAGE, roomItems2.getItemOutcomeImage());

        // If the item is deadly i'll ifnorm the player that they died if its not then the'll be happy to have collected a haunted house item and get to leave.
        //In both cases since an item has been inspected the game ends so I exit the program.
        if (roomItems2.getIsDeadly()) {

            JOptionPane.showMessageDialog(null, "You have collected this item!\nBut doing so has killed you ...\nShown is the room where you died.\n" + backpack, "Location of Death", JOptionPane.PLAIN_MESSAGE, house.currentRoom(currentRoomNumber));

            gameOver = true;
            System.exit(0);
        } else {
            JOptionPane.showMessageDialog(null, "Well now that I've found something cool I can go back home!\n" + backpack, "Item Outcome", JOptionPane.PLAIN_MESSAGE, house.currentRoom(currentRoomNumber));

            gameOver = true;
            System.exit(0);
        }

    }

    //Getter necessary
    public boolean getGameOver() {
        return gameOver;
    }
}
