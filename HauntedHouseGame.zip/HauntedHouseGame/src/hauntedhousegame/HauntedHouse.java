/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hauntedhousegame;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import java.util.StringTokenizer;
import java.util.Scanner;

/**
 *
 * @author dailenperez
 */
public class HauntedHouse
{

    // Makes image ojects per room the user can be in
   

    private ImageIcon livingRoom = new ImageIcon("livingRoomMap.png");
    private ImageIcon frontDoor = new ImageIcon("frontDoorMap.png");
    private ImageIcon bathroom1 = new ImageIcon("bathroom1Map.png");
    private ImageIcon diningRoom = new ImageIcon("diningRoomMap.png");
    private ImageIcon kitchen = new ImageIcon("kitchenMap.png");
    private ImageIcon pantry = new ImageIcon("pantryMap.png");
    private ImageIcon bedroom1 = new ImageIcon("bedroom1Map.png");
    private ImageIcon bathroom2 = new ImageIcon("bathroom2Map.png");
    private ImageIcon bedroom2 = new ImageIcon("bedroom2Map.png");
    private ImageIcon masterBedroom = new ImageIcon("masterBedroomMap.png");
    private ImageIcon masterBathroom = new ImageIcon("masterBathroomMap.png");
    private ImageIcon stairs = new ImageIcon("stairsMap.png");

    // Making variables to re-difne later on as the current room the user is in and the updated room image after they move
    private ImageIcon currentRoomImage = new ImageIcon("houseMap.png");
    // empty global array that I define later of the possible rooms a user can go to from the current oe they're in. Of type String
    //so that I can easily display it with JOptionPane
    private String[] possibleRooms;



  // This method saves the possible target rooms a user can move to based on their current location .
    //Through redefining the possibleRooms String array so that in jOption pane the appropriate rooms can be displayed.
    public void possibleMoves(int currentRoom)
    {

        if (currentRoom == 0)
        {

            possibleRooms = new String[]
            {
                "1", "3", "11"
            };

        } else if (currentRoom == 1)
        {

            possibleRooms = new String[]
            {
                "2", "3", "11"
            };

        } else if (currentRoom == 2)
        {

            possibleRooms = new String[]
            {
                "1"
            };
        } else if (currentRoom == 3)
        {

            possibleRooms = new String[]
            {
                "1", "4", "11"
            };

        } else if (currentRoom == 4)
        {

            possibleRooms = new String[]
            {
                "5", "3"
            };

        } else if (currentRoom == 5)
        {

            possibleRooms = new String[]
            {
                "4"
            };

        } else if (currentRoom == 6)
        {

            possibleRooms = new String[]
            {
                "7", "9", "11"
            };

        } else if (currentRoom == 7)
        {

            possibleRooms = new String[]
            {
                "6", "8"
            };

        } else if (currentRoom == 8)
        {

            possibleRooms = new String[]
            {
                "7", "9"
            };

        } else if (currentRoom == 9)
        {

            possibleRooms = new String[]
            {
                "8", "10", "11"
            };

        } else if (currentRoom == 10)
        {

            possibleRooms = new String[]
            {
                "9"
            };

        } else if (currentRoom == 11)
        {

            possibleRooms = new String[]
            {
                "1", "3", "6", "8", "9"
            };

        } else
        {
            possibleRooms = new String[]
            {
                "0"
            };
        }

    }

    // This method takes in a room number and returns an image of the player being signaled in that room.
    public ImageIcon currentRoom(int currentRoomNumber)
    {
        switch (currentRoomNumber)
        {
            case 0:
                currentRoomImage = frontDoor;
                 break;
            case 1:
                currentRoomImage = livingRoom;
                break;
            case 2:
                currentRoomImage = bathroom1;
                break;
            case 3:
                currentRoomImage = diningRoom;
                break;
            case 4:
                currentRoomImage = kitchen;
                break;
            case 5:
                currentRoomImage = pantry;
                break;
            case 6:
                currentRoomImage = bedroom1;
                break;
            case 7:
                currentRoomImage = bathroom2;
                break;
            case 8:
                currentRoomImage = bedroom2;
                break;
            case 9:
                currentRoomImage = masterBedroom;
                break;
            case 10:
                currentRoomImage = masterBathroom;
                break;
            case 11:
                currentRoomImage = stairs;
                break;
            default:
                currentRoomImage = frontDoor;

        }
        return currentRoomImage;
    }

    //Getter for possibleRooms array
    
    public String[] getPossibleRoomsArray(){
    return possibleRooms;
    }
   
}
