/*
 //********************************************************************************
 // STUDENT NAME:  [Dailen Perez]
 // FIU EMAIL: [dpere344@fiu.edu]
 // CLASS: COP 2210 – [Spring 2018]
 // ASSIGNMENT # [3]
 // DATE: [3/28/18]
 //
 // I hereby swear and affirm that this work is solely my own, and not the work 
 // or the derivative of the work of someone else.
 //********************************************************************************

 */
package hauntedhousegame;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 *
 * @author dailenperez
 */
public class HauntedHouseGame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // Creates a player object to be able to call the methods in it that let the user play the game.
        Player player1 = new Player();
        // The images I show at game intro
        ImageIcon beginGame = new ImageIcon("BeginGame.png");
        ImageIcon frontDoorView = new ImageIcon("hallway.png");

       //Short intro as player enters the haunted house.
        JOptionPane.showMessageDialog(null, "Time to face my fears and enter the neighborhood's haunted house...\nHopefully I'll find something cool to take back home with me.", "Good Luck!", JOptionPane.INFORMATION_MESSAGE, beginGame);
        JOptionPane.showMessageDialog(null, "Well this doesn't look too creepy!\nI should probably use my house map to see what rooms look worthwhile.\nI'll mark my current location with a green circle.", "Oh The Places You Will Go", JOptionPane.INFORMATION_MESSAGE, frontDoorView);

        // While the game is not over keep letting the player explore items and move around.
        do {

            player1.MovePlayer();

            player1.exploreRoomItems();

        } while (!player1.getGameOver());

    }

}
